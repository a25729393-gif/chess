package com.chesscoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.github.bhlangonijr.chesslib.move.Move
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Главный сервис: снимает экран, читает доску, ведёт партию, считает Stockfish'ем
 * и рисует значки поверх доски.
 */
class OverlayService : Service() {

    enum class Mode { FULL, REVIEW, OFF }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val wt = HandlerThread("coach-capture").apply { start() }
    private val wh = Handler(wt.looper)
    private val analysis = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var screenW = 0
    private var screenH = 0
    private var lastFull: Bitmap? = null

    private var overlay: BoardOverlayView? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null
    private var modeChip: TextView? = null
    private var calibRoot: FrameLayout? = null

    @Volatile private var engine: Engine? = null
    @Volatile private var mode = Mode.FULL
    @Volatile private var board: String? = null     // текущая позиция (FEN); null — ждём начало партии
    @Volatile private var running = true
    @Volatile private var evalToken = 0

    private var rect: RectF? = null
    private var calib: Calib? = null
    private var whiteBottom = true

    // распознавание
    private var raw: IntArray? = null
    private var stable = 0
    private var handled = false
    private var unmatched = 0

    // что показываем
    @Volatile private var hintFen = ""
    @Volatile private var hintLines: List<Line> = emptyList()
    @Volatile private var hintMarks: List<Mark> = emptyList()
    @Volatile private var verdictMarks: List<Mark> = emptyList()
    @Volatile private var stateText = ""
    @Volatile private var verdictText = ""
    @Volatile private var hintText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || projection != null) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("coach", "Chess Coach", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "coach")
            .setContentTitle("Chess Coach работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(intent.getIntExtra("code", 0), data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, ui)
        val rd = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = proj.createVirtualDisplay(
            "coach", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )

        loadPrefs()
        stateText = if (calib != null) "Жду начальную позицию новой партии…"
        else "Нажмите «📐 Рамка» и совместите сетку с доской"
        buildUi()
        startEngine()
        wh.post { tick() }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ окна

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fullParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Android 12+: чтобы касания проходили сквозь слой, его непрозрачность должна быть не выше 0.8
        if (!touchable) lp.alpha = 0.8f
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return lp
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 12f
        t.setPadding(dp(10), dp(6), dp(10), dp(6))
        val b = GradientDrawable()
        b.setColor(0xFF3C4043.toInt())
        b.cornerRadius = dp(8).toFloat()
        t.background = b
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.rightMargin = dp(6)
        lp.topMargin = dp(6)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildUi() {
        val ov = BoardOverlayView(this)
        overlay = ov
        wm.addView(ov, fullParams(false))
        syncOverlay()

        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xEE202124.toInt())
        bg.cornerRadius = dp(10).toFloat()
        p.background = bg
        p.setPadding(dp(10), dp(8), dp(10), dp(8))

        val st = TextView(this)
        st.setTextColor(Color.WHITE)
        st.textSize = 12.5f
        st.minLines = 5
        st.maxLines = 5
        st.ellipsize = TextUtils.TruncateAt.END
        statusView = st
        p.addView(st)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val mc = chip("") { cycleMode() }
        modeChip = mc
        row.addView(mc)
        row.addView(chip("📐 Рамка") { showCalib() })
        row.addView(chip("✕ Выход") { stopSelf() })
        p.addView(row)

        val lp = WindowManager.LayoutParams(
            screenW - dp(16),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(40)

        // панель можно перетаскивать за текст
        var dx = 0f
        var dy = 0f
        st.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt()
                    lp.y = (e.rawY + dy).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }

        wm.addView(p, lp)
        panel = p
        panelLp = lp
        updateModeChip()
        render()
        if (rect != null) ui.post { placePanel() }
    }

    /** Ставим панель над доской (или под ней, если сверху нет места). */
    private fun placePanel() {
        val p = panel ?: return
        val lp = panelLp ?: return
        val r = rect ?: return
        p.measure(
            View.MeasureSpec.makeMeasureSpec(lp.width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = p.measuredHeight
        lp.y = if (r.top > h + dp(8)) (r.top - h - dp(8)).toInt() else (r.bottom + dp(8)).toInt()
        wm.updateViewLayout(p, lp)
    }

    private fun syncOverlay() {
        val r = rect?.let { RectF(it) } ?: RectF()
        val wb = whiteBottom
        ui.post {
            overlay?.rect = r
            overlay?.whiteBottom = wb
            overlay?.invalidate()
        }
    }

    private fun updateModeChip() {
        val t = when (mode) {
            Mode.FULL -> "💡 Подсказки"
            Mode.REVIEW -> "🎓 Сам → оценка"
            Mode.OFF -> "⏸ Пауза"
        }
        ui.post { modeChip?.text = t }
    }

    /** Режимы: подсказки + оценка → только оценка после хода → пауза. */
    private fun cycleMode() {
        val old = mode
        mode = Mode.values()[(old.ordinal + 1) % 3]
        updateModeChip()
        wh.post {
            if (mode == Mode.OFF) engine?.stopHints()
            if (old == Mode.OFF) onPosition() else refresh()
        }
    }

    private fun render() = refresh()

    private fun refresh() {
        val m = mode
        val marks = ArrayList<Mark>()
        if (m == Mode.FULL) marks.addAll(hintMarks)
        if (m != Mode.OFF) marks.addAll(verdictMarks)
        overlay?.marks = marks
        val text = when (m) {
            Mode.OFF -> "⏸ Пауза: подсказки выключены, позиция отслеживается.\nИграйте сами, а потом включите режим обратно."
            Mode.REVIEW -> listOf(stateText, verdictText).filter { it.isNotEmpty() }.joinToString("\n")
            Mode.FULL -> listOf(stateText, verdictText, hintText).filter { it.isNotEmpty() }.joinToString("\n")
        }
        ui.post { statusView?.text = text }
    }

    // ------------------------------------------------------------------ калибровка рамки

    private fun showCalib() {
        ui.post {
            if (calibRoot != null) return@post
            val r = rect?.let { RectF(it) } ?: RectF(
                0f, (screenH - screenW) / 2f, screenW.toFloat(), (screenH - screenW) / 2f + screenW
            )
            val root = FrameLayout(this)
            val cv = CalibView(this, r)
            root.addView(cv, FrameLayout.LayoutParams(-1, -1))
            val row = LinearLayout(this)
            row.addView(chip("✓ Готово") { finishCalib(cv.rect) })
            row.addView(chip("Отмена") { hideCalib() })
            val rl = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            rl.bottomMargin = dp(80)
            root.addView(row, rl)
            wm.addView(root, fullParams(true))
            calibRoot = root
        }
    }

    private fun hideCalib() {
        calibRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        calibRoot = null
    }

    private fun finishCalib(r: RectF) {
        val copy = RectF(r)
        hideCalib()
        stateText = "Калибровка…"
        refresh()
        // ждём, пока сетка исчезнет с экрана, и только потом смотрим на доску
        ui.postDelayed({ wh.post { learn(copy) } }, 600)
    }

    private fun learn(r: RectF) {
        pullFrame()
        rect = r
        val bmp = cropBoard(r)
        if (bmp == null) {
            stateText = "Рамка выходит за экран — поправьте её"
            refresh()
            return
        }
        val l = Vision.learn(Vision.features(bmp))
        bmp.recycle()
        val c = l.calib
        if (c == null) {
            calib = null
            stateText = "Калибровка не удалась: ${l.error}"
            refresh()
            return
        }
        calib = c
        whiteBottom = l.whiteBottom
        savePrefs()
        syncOverlay()
        ui.post { placePanel() }
        raw = null
        stable = 0
        handled = false
        startGame()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("coach", MODE_PRIVATE)
        if (p.contains("s")) {
            val l = p.getFloat("l", 0f)
            val t = p.getFloat("t", 0f)
            val s = p.getFloat("s", 0f)
            rect = RectF(l, t, l + s, t + s)
        }
        if (p.contains("te")) calib = Calib(p.getFloat("te", 0f), p.getFloat("tl", 0f))
    }

    private fun savePrefs() {
        val r = rect ?: return
        val c = calib ?: return
        getSharedPreferences("coach", MODE_PRIVATE).edit()
            .putFloat("l", r.left).putFloat("t", r.top).putFloat("s", r.width())
            .putFloat("te", c.thrEdge).putFloat("tl", c.thrLum)
            .apply()
    }

    // ------------------------------------------------------------------ захват экрана

    private fun toBitmap(img: Image): Bitmap {
        val pl = img.planes[0]
        val rowPx = pl.rowStride / pl.pixelStride
        val b = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888)
        b.copyPixelsFromBuffer(pl.buffer)
        img.close()
        return b
    }

    /** Забираем свежий кадр, если он есть (на неподвижном экране новых кадров нет). */
    private fun pullFrame(): Boolean {
        val img = reader?.acquireLatestImage() ?: return false
        val old = lastFull
        lastFull = toBitmap(img)
        old?.recycle()
        return true
    }

    private fun cropBoard(r: RectF): Bitmap? {
        val full = lastFull ?: return null
        val x = r.left.toInt()
        val y = r.top.toInt()
        val s = r.width().toInt()
        if (x < 0 || y < 0 || s < 80 || x + s > full.width || y + s > full.height) return null
        return Bitmap.createBitmap(full, x, y, s, s)
    }

    private fun tick() {
        if (!running) return
        try {
            step()
        } catch (e: Throwable) {
            stateText = "Ошибка: ${e.message}"
            refresh()
        }
        wh.postDelayed({ tick() }, 450)
    }

    private fun step() {
        val fresh = pullFrame()
        val r = rect ?: return
        val cal = calib ?: return
        val g: IntArray
        val cur = raw
        if (fresh || cur == null) {
            val bmp = cropBoard(r) ?: return
            val f = Vision.features(bmp)
            bmp.recycle()
            if (f.all { it.lum < 3f }) {
                stateText = "Чёрный кадр: приложение запрещает запись экрана"
                refresh()
                return
            }
            g = Vision.grid(f, cal)
        } else {
            g = cur
        }
        val prev = raw
        if (prev != null && g.contentEquals(prev)) {
            stable++
        } else {
            raw = g
            stable = 1
            handled = false
        }
        // позицию принимаем, только когда два кадра подряд одинаковые (фигура не едет)
        if (stable < 2 || handled) return
        handled = true
        process(g)
    }

    // ------------------------------------------------------------------ ведение партии

    private fun process(g: IntArray) {
        val so = Vision.startOrientation(g)
        if (so != null) {
            if (board != START_FEN || whiteBottom != so) {
                whiteBottom = so
                syncOverlay()
                startGame()
            }
            return
        }
        val fen = board
        if (fen == null) {
            stateText = "Жду начальную позицию новой партии…"
            refresh()
            return
        }
        val occ = Vision.toOcc(g, whiteBottom)
        if (occ.contentEquals(occOf(fen))) {
            unmatched = 0
            return
        }
        val path = findPath(fen, occ, 1) ?: findPath(fen, occ, 2)
        if (path == null) {
            unmatched++
            if (unmatched >= 3) {
                stateText = "Не узнаю позицию. Начните партию заново или поправьте «📐 Рамка»"
                refresh()
            }
            return
        }
        unmatched = 0
        engine?.stopHints()
        var cur = fen
        for (m in path) {
            val next = applyMove(cur, m)
            onMove(cur, m, next)
            cur = next
        }
        board = cur
        onPosition()
    }

    private fun startGame() {
        engine?.stopHints()
        evalToken++
        board = START_FEN
        verdictMarks = emptyList()
        hintMarks = emptyList()
        verdictText = ""
        hintText = ""
        hintFen = ""
        hintLines = emptyList()
        stateText = "♟ Партия началась: вы — " + (if (whiteBottom) "белые" else "чёрные")
        refresh()
        onPosition()
    }

    private fun onMove(before: String, m: Move, after: String) {
        val uci = m.uci()
        if (whiteToMove(before) == whiteBottom) {
            // ходил пользователь
            val token = ++evalToken
            verdictMarks = emptyList()
            hintMarks = emptyList()
            hintText = ""
            if (mode != Mode.OFF) {
                verdictText = "Оцениваю ваш ход ${moveText(before, uci)}…"
                bg { evaluate(before, uci, after, token) }
            } else {
                verdictText = ""
            }
            refresh()
        }
    }

    /** Позиция изменилась: если ходить нам — запускаем анализ для подсказок. */
    private fun onPosition() {
        hintMarks = emptyList()
        hintText = ""
        val fen = board
        if (fen == null || mode == Mode.OFF) {
            refresh()
            return
        }
        if (whiteToMove(fen) != whiteBottom) {
            hintText = "Ход соперника…"
            refresh()
            return
        }
        if (!hasLegalMoves(fen)) {
            hintText = "Партия окончена"
            refresh()
            return
        }
        refresh()
        bg { runHints(fen) }
    }

    // ------------------------------------------------------------------ движок

    private fun bg(task: () -> Unit) {
        analysis.execute {
            try {
                task()
            } catch (e: Throwable) {
                stateText = "Ошибка анализа: ${e.message}"
                refresh()
            }
        }
    }

    private fun startEngine() {
        val f = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) {
            stateText = "❌ Нет Stockfish (libstockfish.so). См. README"
            refresh()
            return
        }
        val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)
        analysis.execute {
            try {
                engine = Engine(f.absolutePath, threads)
            } catch (e: Exception) {
                stateText = "❌ Stockfish не запустился: ${e.message}"
                refresh()
            }
        }
    }

    private fun runHints(fen: String) {
        if (fen != board) return
        val eng = engine ?: return
        var last = 0L
        val lines = eng.analyze(fen, 3, 2500, cancellable = true) { ls ->
            val now = System.currentTimeMillis()
            if (now - last > 400 && ls.isNotEmpty() && ls[0].depth >= 8) {
                last = now
                hintFen = fen
                hintLines = ls
                showHints(fen, ls)
            }
        }
        if (lines.isNotEmpty()) {
            hintFen = fen
            hintLines = lines
            showHints(fen, lines)
        }
    }

    private fun showHints(fen: String, ls: List<Line>) {
        if (fen != board || mode == Mode.OFF) return
        val userWhite = whiteToMove(fen)
        val winBest = winPct(ls[0].cp)
        val gap = if (ls.size > 1) winBest - winPct(ls[1].cp) else null
        val marks = ArrayList<Mark>()
        val sb = StringBuilder()
        for ((i, l) in ls.withIndex()) {
            val mv = l.pv.firstOrNull() ?: continue
            if (mv.length < 4) continue
            val winL = winPct(l.cp)
            val q = classify(
                if (i == 0) 0.0 else lossOf(ls[0].cp, l.cp),
                winBest, winL, i == 0, if (i == 0) gap else null,
                sacrifice(fen, l.pv, userWhite)
            )
            marks.add(Mark(mv[0] - 'a', mv[1] - '1', 1, q, "${i + 1}"))
            marks.add(Mark(mv[2] - 'a', mv[3] - '1', 0, q, q.sym, q == Quality.BRILLIANT))
            sb.append("${i + 1}. ${moveText(fen, mv)}   ${q.sym} ${fmtCp(l.cp)}\n")
        }
        hintMarks = marks.reversed()   // лучший ход рисуется последним, поверх остальных
        hintText = sb.toString().trimEnd()
        refresh()
    }

    /** Оценка хода пользователя: сравниваем лучший вариант до хода и позицию после него. */
    private fun evaluate(before: String, uci: String, after: String, token: Int) {
        val eng = engine ?: return
        val userWhite = whiteToMove(before)
        var pre = if (hintFen == before) hintLines else emptyList()
        if (pre.isEmpty() || pre[0].depth < 10) pre = eng.analyze(before, 3, 700)
        val post = eng.analyze(after, 1, 800)
        if (pre.isEmpty()) return

        val bestCp = pre[0].cp
        val afterCp = if (post.isNotEmpty()) -post[0].cp else (if (bestCp > 5000) 10000 else 0)
        val winB = winPct(bestCp)
        val winA = winPct(afterCp)
        val isTop = pre[0].pv.firstOrNull() == uci
        val gap = if (pre.size > 1) winB - winPct(pre[1].cp) else null
        val fullPv = listOf(uci) + (post.firstOrNull()?.pv ?: emptyList())
        val sac = sacrifice(before, fullPv, userWhite)
        val loss = if (isTop) 0.0 else max(0.0, winB - winA)
        val q = classify(loss, winB, winA, isTop, gap, sac)

        if (token != evalToken) return   // пользователь уже сделал следующий ход
        verdictMarks = listOf(Mark(uci[2] - 'a', uci[3] - '1', 0, q, q.sym, q == Quality.BRILLIANT))
        verdictText = "Ваш ход ${moveText(before, uci)}: ${q.sym} ${q.label} (${fmtCp(afterCp)})"
        refresh()
    }

    // ------------------------------------------------------------------ завершение

    override fun onDestroy() {
        running = false
        wh.removeCallbacksAndMessages(null)
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { calibRoot?.let { wm.removeView(it) } } catch (_: Exception) {}
        analysis.shutdownNow()
        engine?.close()
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        wt.quitSafely()
        super.onDestroy()
    }
}
