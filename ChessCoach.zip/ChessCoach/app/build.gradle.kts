plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chesscoach"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chesscoach"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters.add("arm64-v8a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs {
            // нужно, чтобы libstockfish.so распаковался на диск и его можно было запустить
            useLegacyPackaging = true
            keepDebugSymbols.add("**/libstockfish.so")
        }
    }
}

dependencies {
    implementation("com.github.bhlangonijr:chesslib:1.3.3")
}
