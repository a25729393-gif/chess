package com.chesscoach

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Одна линия анализа. cp — оценка в сотых пешки с точки зрения стороны, которая ходит. */
data class Line(val multipv: Int, val cp: Int, val depth: Int, val pv: List<String>)

/** Обёртка над процессом Stockfish (протокол UCI). */
class Engine(path: String, threads: Int) {
    private val proc: Process = ProcessBuilder(path).redirectErrorStream(true).start()
    private val writer = BufferedWriter(OutputStreamWriter(proc.outputStream))
    private val reader = BufferedReader(InputStreamReader(proc.inputStream))
    private val lines = HashMap<Int, Line>()
    private val done = LinkedBlockingQueue<Unit>()

    @Volatile private var listener: ((List<Line>) -> Unit)? = null
    @Volatile private var cancel = false
    @Volatile private var cancellable = false

    init {
        send("uci")
        send("setoption name Threads value $threads")
        send("setoption name Hash value 64")
        send("isready")
        Thread { readLoop() }.apply { isDaemon = true }.start()
    }

    /**
     * Блокирующий анализ позиции. Возвращает линии (отсортированы по multipv).
     * cancellable = true — анализ можно прервать через stopHints().
     */
    fun analyze(
        fen: String,
        multiPv: Int,
        ms: Int,
        cancellable: Boolean = false,
        onInfo: ((List<Line>) -> Unit)? = null
    ): List<Line> {
        synchronized(lines) { lines.clear() }
        listener = onInfo
        cancel = false
        this.cancellable = cancellable
        done.clear()
        send("setoption name MultiPV value $multiPv")
        send("position fen $fen")
        send("go movetime $ms")
        while (done.poll(100, TimeUnit.MILLISECONDS) == null) {
            if (cancel) send("stop")
            if (!proc.isAlive) break
        }
        listener = null
        this.cancellable = false
        return snapshot()
    }

    /** Прервать текущий «лёгкий» анализ (подсказки). Оценку хода не трогает. */
    fun stopHints() {
        if (cancellable) {
            cancel = true
            send("stop")
        }
    }

    fun close() {
        send("quit")
        proc.destroy()
    }

    private fun snapshot(): List<Line> =
        synchronized(lines) { lines.values.sortedBy { it.multipv } }

    private fun send(cmd: String) {
        try {
            synchronized(writer) {
                writer.write(cmd)
                writer.write("\n")
                writer.flush()
            }
        } catch (_: Exception) {
        }
    }

    private fun readLoop() {
        try {
            while (true) {
                val l = reader.readLine() ?: break
                if (l.startsWith("info") && l.contains(" pv ")) parseInfo(l)
                else if (l.startsWith("bestmove")) done.offer(Unit)
            }
        } catch (_: Exception) {
        }
    }

    private fun parseInfo(l: String) {
        if (l.contains("lowerbound") || l.contains("upperbound")) return
        val t = l.split(" ")
        var depth = 0
        var mpv = 1
        var cp = 0
        var pvStart = -1
        var i = 1
        while (i < t.size) {
            when (t[i]) {
                "depth" -> { depth = t.getOrNull(i + 1)?.toIntOrNull() ?: 0; i++ }
                "multipv" -> { mpv = t.getOrNull(i + 1)?.toIntOrNull() ?: 1; i++ }
                "score" -> {
                    val kind = t.getOrNull(i + 1)
                    val v = t.getOrNull(i + 2)?.toIntOrNull() ?: 0
                    cp = if (kind == "mate") {
                        if (v > 0) 10000 - v * 10 else -10000 - v * 10
                    } else v
                    i += 2
                }
                "pv" -> { pvStart = i + 1; i = t.size }
            }
            i++
        }
        if (pvStart < 0 || pvStart >= t.size) return
        val line = Line(mpv, cp, depth, t.subList(pvStart, t.size))
        synchronized(lines) { lines[mpv] = line }
        listener?.invoke(snapshot())
    }
}
