package com.chesscoach

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

/** Значок на углу клетки. corner: 0 — правый верхний, 1 — левый верхний. */
class Mark(
    val file: Int,
    val rank: Int,
    val corner: Int,
    val q: Quality,
    val text: String,
    val diamond: Boolean = false
)

/**
 * Прозрачный слой поверх доски. Значки маленькие и сидят в углах клеток,
 * чтобы не мешать чтению фигур с экрана.
 */
class BoardOverlayView(ctx: Context) : View(ctx) {
    var rect = RectF()
    var whiteBottom = true

    @Volatile
    var marks: List<Mark> = emptyList()
        set(v) {
            field = v
            postInvalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        if (rect.width() < 10f) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val sq = rect.width() / 8f
        val r = sq * 0.12f
        ring.strokeWidth = max(1.5f, r * 0.12f)
        txt.textSize = r * 1.15f
        for (m in marks) {
            val col = if (whiteBottom) m.file else 7 - m.file
            val row = if (whiteBottom) 7 - m.rank else m.rank
            val cx = rect.left + col * sq + (if (m.corner == 0) sq - r else r)
            val cy = rect.top + row * sq + r
            fill.color = m.q.color
            c.drawCircle(cx, cy, r, fill)
            c.drawCircle(cx, cy, r, ring)
            if (m.diamond) {
                val k = r * 0.62f
                path.reset()
                path.moveTo(cx, cy - k)
                path.lineTo(cx + k, cy)
                path.lineTo(cx, cy + k)
                path.lineTo(cx - k, cy)
                path.close()
                c.drawPath(path, txt)
            } else {
                val fm = txt.fontMetrics
                c.drawText(m.text, cx, cy - (fm.ascent + fm.descent) / 2f, txt)
            }
        }
    }
}

/** Экран калибровки: двигаем и растягиваем сетку 8×8, пока она не совпадёт с доской. */
class CalibView(ctx: Context, val rect: RectF) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFEB3B.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFEB3B.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private var mode = 0
    private var lx = 0f
    private var ly = 0f

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        c.drawRect(rect, line)
        val s = rect.width() / 8f
        for (i in 1..7) {
            c.drawLine(rect.left + i * s, rect.top, rect.left + i * s, rect.bottom, line)
            c.drawLine(rect.left, rect.top + i * s, rect.right, rect.top + i * s, line)
        }
        c.drawCircle(rect.right, rect.bottom, 18f * d, fill)
        c.drawText("Совместите сетку с доской (начальная позиция).", 16f * d, 110f * d, txt)
        c.drawText("Двигайте сетку пальцем, размер — жёлтым кружком.", 16f * d, 134f * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.rawX
        val y = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = when {
                    hypot(x - rect.right, y - rect.bottom) < 40f * d -> 2
                    rect.contains(x, y) -> 1
                    else -> 0
                }
                lx = x
                ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - lx
                val dy = y - ly
                if (mode == 1) {
                    rect.offset(dx, dy)
                } else if (mode == 2) {
                    val size = max(200f, rect.width() + (dx + dy) / 2f)
                    rect.set(rect.left, rect.top, rect.left + size, rect.top + size)
                }
                lx = x
                ly = y
                invalidate()
            }
        }
        return true
    }
}
