package com.chesscoach

import android.graphics.Bitmap
import kotlin.math.abs

/** Пороги, которые приложение само подбирает по начальной позиции. */
class Calib(val thrEdge: Float, val thrLum: Float)

class Learned(val calib: Calib?, val whiteBottom: Boolean, val error: String?)

/**
 * Чтение доски со скриншота. Тип фигуры не распознаём — только «пусто / белая / чёрная».
 * Какая это фигура, знает программа сама, отслеживая ходы с начальной позиции.
 */
object Vision {
    class Feat(val edge: Float, val lum: Float)

    private fun lumOf(p: Int): Int =
        (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10

    /** 64 признака клеток, индекс = row*8+col (row считается сверху). */
    fun features(bmp: Bitmap): Array<Feat> {
        val n = bmp.width
        val px = IntArray(n * bmp.height)
        bmp.getPixels(px, 0, n, 0, 0, n, bmp.height)
        val sf = n / 8f
        val s = sf.toInt()
        return Array(64) { i -> cell(px, n, ((i % 8) * sf).toInt(), ((i / 8) * sf).toInt(), s) }
    }

    private fun cell(px: IntArray, stride: Int, x0: Int, y0: Int, s: Int): Feat {
        val a = (s * 0.22f).toInt()
        val b = (s * 0.78f).toInt()
        var edges = 0
        var total = 0
        for (y in a until b - 1) {
            val row = (y0 + y) * stride + x0
            for (x in a until b - 1) {
                val l = lumOf(px[row + x])
                if (abs(l - lumOf(px[row + x + 1])) > 24 || abs(l - lumOf(px[row + stride + x])) > 24) edges++
                total++
            }
        }
        var sum = 0
        var cnt = 0
        val c0 = (s * 0.4f).toInt()
        val c1 = (s * 0.6f).toInt()
        for (y in c0 until c1) for (x in c0 until c1) {
            sum += lumOf(px[(y0 + y) * stride + x0 + x])
            cnt++
        }
        return Feat(edges.toFloat() / max1(total), sum.toFloat() / max1(cnt))
    }

    private fun max1(v: Int) = if (v < 1) 1 else v

    /** Калибровка по начальной позиции. */
    fun learn(f: Array<Feat>): Learned {
        val emptyEdges = (16..47).map { f[it].edge }.sortedDescending()
        val occEdges = ((0..15) + (48..63)).map { f[it].edge }.sorted()
        val emptyHigh = emptyEdges[1]
        val occLow = occEdges[1]
        if (occLow <= emptyHigh * 1.3f + 0.01f) {
            return Learned(null, true, "не вижу фигур — выровняйте рамку и откройте начальную позицию")
        }
        val thrEdge = (emptyHigh + occLow) / 2f

        val top = (0..15).map { f[it].lum }
        val bottom = (48..63).map { f[it].lum }
        val whiteBottom = bottom.average() > top.average()
        val whites = if (whiteBottom) bottom else top
        val blacks = if (whiteBottom) top else bottom
        val wLow = whites.sorted()[1]
        val bHigh = blacks.sortedDescending()[1]
        if (wLow - bHigh < 30f) {
            return Learned(null, whiteBottom, "не отличаю белые фигуры от чёрных — проверьте рамку")
        }
        return Learned(Calib(thrEdge, (wLow + bHigh) / 2f), whiteBottom, null)
    }

    /** 0 пусто, 1 белая, 2 чёрная — в экранном порядке (row сверху). */
    fun grid(f: Array<Feat>, c: Calib): IntArray = IntArray(64) { i ->
        val x = f[i]
        if (x.edge < c.thrEdge) 0 else if (x.lum > c.thrLum) 1 else 2
    }

    /** Переводим экранную сетку в занятость клеток a1..h8. */
    fun toOcc(g: IntArray, whiteBottom: Boolean): IntArray {
        val occ = IntArray(64)
        for (r in 0..7) for (c in 0..7) {
            val file = if (whiteBottom) c else 7 - c
            val rank = if (whiteBottom) 7 - r else r
            occ[rank * 8 + file] = g[r * 8 + c]
        }
        return occ
    }

    /** Если на экране начальная позиция: true — белые внизу, false — чёрные внизу, null — не начальная. */
    fun startOrientation(g: IntArray): Boolean? {
        for (i in 16..47) if (g[i] != 0) return null
        val t = g[0]
        val b = g[48]
        if (t == 0 || b == 0 || t == b) return null
        for (i in 0..15) if (g[i] != t) return null
        for (i in 48..63) if (g[i] != b) return null
        return b == 1
    }
}
