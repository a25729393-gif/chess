package com.chesscoach

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.move.Move
import kotlin.math.exp
import kotlin.math.max

const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

/** Оценки хода. */
enum class Quality(val label: String, val sym: String, val color: Int) {
    BRILLIANT("Блестящий", "💎", 0xFF1BACA6.toInt()),
    GREAT("Отличный", "!", 0xFF5C8BB0.toInt()),
    BEST("Лучший", "★", 0xFF7FA650.toInt()),
    GOOD("Хороший", "✓", 0xFF96AF8B.toInt()),
    INACCURACY("Неточность", "?!", 0xFFE0B21A.toInt()),
    MISTAKE("Ошибка", "?", 0xFFE58F2A.toInt()),
    BLUNDER("Зевок", "??", 0xFFCA3431.toInt())
}

val GLYPH = mapOf(
    'K' to "♔", 'Q' to "♕", 'R' to "♖", 'B' to "♗", 'N' to "♘", 'P' to "♙",
    'k' to "♚", 'q' to "♛", 'r' to "♜", 'b' to "♝", 'n' to "♞", 'p' to "♟"
)

// ---------- работа с шахматной логикой (библиотека chesslib) ----------

fun newBoard(fen: String = START_FEN): Board = Board().also { it.loadFromFen(fen) }

fun Move.uci(): String {
    var s = this.from.toString().lowercase() + this.to.toString().lowercase()
    if (this.promotion != Piece.NONE) s += this.promotion.fenSymbol.lowercase()
    return s
}

fun whiteToMove(fen: String): Boolean = fen.split(' ')[1] == "w"

/** Занятость клеток: индекс = rank*8+file (a1 = 0), значение 0 пусто / 1 белая / 2 чёрная. */
fun occOf(fen: String): IntArray {
    val occ = IntArray(64)
    var rank = 7
    var file = 0
    for (ch in fen.substringBefore(' ')) {
        when {
            ch == '/' -> { rank--; file = 0 }
            ch.isDigit() -> file += ch.digitToInt()
            else -> { occ[rank * 8 + file] = if (ch.isUpperCase()) 1 else 2; file++ }
        }
    }
    return occ
}

fun pieceAt(fen: String, file: Int, rank: Int): Char {
    var r = 7
    var f = 0
    for (ch in fen.substringBefore(' ')) {
        when {
            ch == '/' -> { r--; f = 0 }
            ch.isDigit() -> f += ch.digitToInt()
            else -> { if (r == rank && f == file) return ch; f++ }
        }
    }
    return ' '
}

fun applyMove(fen: String, m: Move): String {
    val b = newBoard(fen)
    b.doMove(m)
    return b.fen
}

fun applyUci(fen: String, uci: String): String? {
    val b = newBoard(fen)
    for (m in b.legalMoves()) {
        if (m.uci() == uci) {
            b.doMove(m)
            return b.fen
        }
    }
    return null
}

fun hasLegalMoves(fen: String): Boolean = newBoard(fen).legalMoves().isNotEmpty()

/**
 * Ищем последовательность ходов (до maxPlies), после которой занятость клеток
 * совпадает с тем, что мы увидели на экране.
 */
fun findPath(fen: String, target: IntArray, maxPlies: Int): List<Move>? {
    var frontier: List<Pair<String, List<Move>>> = listOf(fen to emptyList())
    for (d in 1..maxPlies) {
        val next = ArrayList<Pair<String, List<Move>>>()
        val hits = ArrayList<List<Move>>()
        for ((f, path) in frontier) {
            val b = newBoard(f)
            for (m in b.legalMoves()) {
                val b2 = newBoard(f)
                b2.doMove(m)
                val f2 = b2.fen
                val p2 = path + m
                if (occOf(f2).contentEquals(target)) hits.add(p2)
                else if (d < maxPlies) next.add(f2 to p2)
            }
        }
        if (hits.isNotEmpty()) {
            // при превращении пешки считаем, что это ферзь
            return hits.firstOrNull { it.last().uci().endsWith("q") } ?: hits[0]
        }
        frontier = next
    }
    return null
}

// ---------- материал и жертвы ----------

private fun material(fen: String, white: Boolean): Int {
    var s = 0
    for (ch in fen.substringBefore(' ')) {
        val v = when (ch.lowercaseChar()) {
            'p' -> 1; 'n', 'b' -> 3; 'r' -> 5; 'q' -> 9; else -> 0
        }
        if (v > 0 && ch.isUpperCase() == white) s += v
    }
    return s
}

private fun balance(fen: String, white: Boolean) = material(fen, white) - material(fen, !white)

/** Сколько материала сторона потеряла, если сыграть начало варианта pv (до 4 полуходов). */
fun sacrifice(fen: String, pv: List<String>, white: Boolean): Int {
    if (pv.size < 2) return 0
    val n = if (pv.size >= 4) 4 else pv.size
    var cur = fen
    for (i in 0 until n) cur = applyUci(cur, pv[i]) ?: return 0
    return balance(fen, white) - balance(cur, white)
}

// ---------- оценка хода ----------

fun winPct(cp: Int): Double = 100.0 / (1.0 + exp(-0.00368208 * cp))

/**
 * loss — потеря в процентах шанса на победу, winBefore/winAfter — шанс до и после,
 * isTop — ход совпал с первой линией движка, gap — отрыв первой линии от второй (в %),
 * sac — сколько материала отдано.
 */
fun classify(loss: Double, winBefore: Double, winAfter: Double, isTop: Boolean, gap: Double?, sac: Int): Quality =
    when {
        loss < 2.0 && sac >= 2 && winAfter > 45.0 && winBefore < 90.0 -> Quality.BRILLIANT
        loss < 1.0 && isTop && gap != null && gap >= 12.0 -> Quality.GREAT
        loss < 1.0 -> Quality.BEST
        loss < 5.0 -> Quality.GOOD
        loss < 10.0 -> Quality.INACCURACY
        loss < 15.0 -> Quality.MISTAKE
        else -> Quality.BLUNDER
    }

fun fmtCp(cp: Int): String = when {
    cp >= 10000 -> "мат"
    cp >= 9000 -> "мат в ${(10000 - cp) / 10}"
    cp <= -9000 -> "вам мат в ${(10000 + cp) / 10}"
    else -> String.format(java.util.Locale.US, "%+.1f", cp / 100.0)
}

fun moveText(fen: String, uci: String): String {
    val p = pieceAt(fen, uci[0] - 'a', uci[1] - '1')
    return "${GLYPH[p] ?: ""} ${uci.substring(0, 2)}→${uci.substring(2, 4)}"
}

fun lossOf(best: Int, other: Int): Double = max(0.0, winPct(best) - winPct(other))
