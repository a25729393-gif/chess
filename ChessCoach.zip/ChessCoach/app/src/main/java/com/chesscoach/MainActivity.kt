package com.chesscoach

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val reqCapture = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        fun text(t: String, size: Float = 15f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, pad / 2, 0, pad / 2)
            return v
        }

        root.addView(text("♟ Chess Coach", 24f))
        root.addView(
            text(
                "Помощник для тренировки: смотрит на доску в приложении chess.com (партии против ботов), " +
                    "подсказывает лучшие ходы и оценивает ваши — 💎 блестящий, ★ лучший, ✓ хороший, " +
                    "?! неточность, ? ошибка, ?? зевок.\n\n" +
                    "Только для партий против ботов и тренировки. Не используйте в играх против людей."
            )
        )

        val sf = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        root.addView(
            text(
                if (sf.exists()) "✅ Stockfish найден"
                else "❌ Stockfish не найден. Положите libstockfish.so в app/src/main/jniLibs/arm64-v8a/ и пересоберите (см. README)."
            )
        )

        val b1 = Button(this)
        b1.text = "1. Разрешить окна поверх других приложений"
        b1.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        root.addView(b1)

        val b2 = Button(this)
        b2.text = "2. Запустить помощника"
        b2.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_LONG).show()
            } else {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
            }
        }
        root.addView(b2)

        root.addView(
            text(
                "Дальше: откройте chess.com, начните партию с ботом, на панели помощника " +
                    "нажмите «📐 Рамка», совместите сетку с доской и нажмите «✓ Готово». " +
                    "Работает в вертикальной ориентации."
            ).also { it.gravity = Gravity.START }
        )

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            finish()
        }
    }
}
